

/* JQuerry */

$(document).ready(function(){

  $("#whatsapp").click(function(){
      window.open("https://chat.whatsapp.com/IPL6MtAq4E8AokIFfGZB79", "_blank")
  });

  $("#instagram").click(function(){
    window.open("https://www.instagram.com/msa_uncc/?hl=en", "_blank")
  });

  $("#whatsapp").hover(function(){
    $(this).css("background-color", "#25D366");
    }, function(){
    $(this).css("background-color", "#f1f1f1");
  });

  $("#instagram").hover(function(){
    $(this).css("background-color", "#c32aa3");
    }, function(){
    $(this).css("background-color", "#f1f1f1");
  });

});



/* Slide Show */

let slideIndex = 1;
showSlides(slideIndex);

// Next/previous controls
function plusSlides(n) {
  showSlides(slideIndex += n);
}

// Thumbnail image controls
function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  let dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";
  dots[slideIndex-1].className += " active";
}